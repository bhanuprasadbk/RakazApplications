const db = require('../config/db');

module.exports = {

    getDeviceReport: (body, callback) => {
        const { start_date, end_date, customer_id, limit, page } = body;       
        const offset = (page - 1) * limit;
        const query = `
            SELECT 
    d.id AS device_id,
    d.deviceName,
    d.devicemake,
    d.devicemodel,
    c.customer_admin_name,
    s.id AS sensor_id,
    s.sensortype,
    JSON_ARRAYAGG(
        JSON_OBJECT(
            'parameter', sp.sensorParameter,
            'unit', sp.unit,
            'min_threshold', sp.min_threshold_limit,
            'max_threshold', sp.max_threshold_limit,
            'index_start', sp.index_start,
            'index_end', sp.index_end
        )
    ) AS parameters
FROM tbl_devices d
LEFT JOIN tbl_customers c 
    ON d.customeradmin = c.id
JOIN tbl_sensors s 
    ON FIND_IN_SET(s.id, d.sensortype) > 0
JOIN tbl_sensor_parameters sp
    ON sp.sensor_id = s.id
WHERE d.is_deleted = 0 AND d.created_on BETWEEN ? AND ?
AND (c.id = ? OR NULL IS NULL)  -- Pass your customer ID if needed
GROUP BY d.id, s.id
ORDER BY d.id, s.id 
LIMIT ? OFFSET ?`;
        db.query(query, [start_date, end_date, customer_id, limit, offset], (error, results) => {
            if (error) return callback(error, null);
            return callback(null, results);
        });
    }
}